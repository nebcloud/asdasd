Terrarium License v1

This license applies to the following files:
```
  deepslate_calorite_ore.png
  deepslate_desh_ore.png
  deepslate_ice_shard_ore.png
  deepslate_ostrum_ore.png
  glacio_copper_ore.png
  glacio_ice_shard_ore.png
  glacio_iron_ore.png
  glacio_lapis_ore.png
  mars_ice_shard_ore.png
  mars_diamond_ore.png
  mars_iron_ore.png
  mars_ostrum_ore.png
  mercury_iron_ore.png
  moon_ice_shard_ore.png
  moon_ore_cheese.png
  moon_ore_desh.png
  moon_ore_iron.png
  venus_calorite_ore.png
  venus_diamond_ore.png
  venus_gold_ore.png
```

0. Additional Definitions 
“Assets” refer to any file, image or text found under a “…/resources/assets/…” directory
“Code” refers to any class, file, or data found under a “.../java/…” or “.../resources/data/…” directory

1. Per the definitions above, Code is licensed under the “MIT” License, found below
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

2. Per the definitions above, Assets are “All Rights Reserved”

